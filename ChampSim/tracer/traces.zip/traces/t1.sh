xz -kv dop.champsim
xz -kv greeks.champsim
xz -kv photon.champsim
xz -kv pi.champsim
